from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='profile',
            name='avatar_file',
            field=models.FileField(blank=True, upload_to='avatars/'),
        ),
    ]
